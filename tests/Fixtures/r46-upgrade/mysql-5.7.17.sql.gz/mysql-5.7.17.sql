
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author` (
  `name` varchar(255) NOT NULL,
  `threadCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `authorThreadCountIndex` (`threadCount`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `author` WRITE;
/*!40000 ALTER TABLE `author` DISABLE KEYS */;
INSERT INTO `author` VALUES ('旧作者1',1),('旧作者2',1),('旧作者3',1),('旧作者4',1),('旧作者5',1),('旧作者6',1);
/*!40000 ALTER TABLE `author` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `entryID` bigint(20) NOT NULL,
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `body` mediumtext,
  `host` varchar(512) DEFAULT NULL,
  `dateTime` bigint(20) DEFAULT NULL,
  `hash` varchar(512) DEFAULT NULL,
  `evaluation` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`entryID`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1200000001,1200001011,'旧読者1',NULL,'旧コメント\r\n<b>感想</b> & \"引用\"','192.0.2.21',1200001011,'110004811c75263d71c6d1aa2efa7923a47502efee93b95c6cf3a92fff1611c5ce07e02d95386c52d62dc6b3dd64ca07567d7aaaabbbbccccdddd',1200001011),(1200000001,1200001012,'','','','192.0.2.22',1200001012,'110002031a31d83f0be4fbbe0ef08130a8ee53763636efd10ee301d575b33387da5b473a78d5b55d9f7e7a1b949285082c0b6aaaabbbbccccdddd',NULL),(1200000002,1200001021,'旧読者2',NULL,'旧コメント\r\n<b>感想</b> & \"引用\"','192.0.2.21',1200001021,'11000776e3de435f4926d53ca327d27a604974df7484c29bc81e92702014ddf128d3ed73ab0736e31ea01f33df9ff1c87ba3eaaaabbbbccccdddd',1200001021),(1200000002,1200001022,'','','','192.0.2.22',1200001022,'110002b48b3804335f09f733d610b5857b967fad35ecf86b3f45b9bc66d608d8a2b76e25bb78c4691de00cfc6d971caea7bc9aaaabbbbccccdddd',NULL),(1200000003,1200001031,'旧読者3',NULL,'旧コメント\r\n<b>感想</b> & \"引用\"','192.0.2.21',1200001031,'1100057e38aef4b092c85720df46b61d97a7363e26c3e26e5bb4484560762c09ca994a82c578f3ab2fa25688db2b375099328aaaabbbbccccdddd',1200001031),(1200000003,1200001032,'','','','192.0.2.22',1200001032,'1100091f9ebe882ce052f3d6b26d108550bf3f0d0fa5fcb7940e4b20590606dfe169fff6408e492ebec6755212dca1f105306aaaabbbbccccdddd',NULL),(1200000004,1200001041,'旧読者4',NULL,'旧コメント\r\n<b>感想</b> & \"引用\"','192.0.2.21',1200001041,'11000efa612216c9838ea9be58b33f456dbfbcb05edf6d5d24371f6c5b9ba24880218d37b7e93cc0508e800ce6cb3692be47daaaabbbbccccdddd',1200001041),(1200000004,1200001042,'','','','192.0.2.22',1200001042,'110007136bd7399b269d8d086988eae650a5bedfbfd7f0c53eb67c5e799636e46faab6388fc8e9cad7eeb3b20b27377e6f2a3aaaabbbbccccdddd',NULL),(1200000005,1200001051,'旧読者5',NULL,'旧コメント\r\n<b>感想</b> & \"引用\"','192.0.2.21',1200001051,'11000cf5838aace8281feace28f65ed3cadda8ff7bb4e5f5e55e5d41c705c214532a0999574c5f39601c9e0d2ed2ba2e06084aaaabbbbccccdddd',1200001051),(1200000005,1200001052,'','','','192.0.2.22',1200001052,'110001da1a7d35b435a8321e5d6e51007d06597e1f2e8b1b45dd61f31dbf91e20928cd630a3d319c77a3acb965b712a627b0eaaaabbbbccccdddd',NULL),(1200000006,1200001061,'旧読者6',NULL,'旧コメント\r\n<b>感想</b> & \"引用\"','192.0.2.21',1200001061,'110001a86636f210a1f46f81fa5bef06284d15097947eb6639104322ebf9ca6f8b08b2748573a584957572a0b666dd6ba3e30aaaabbbbccccdddd',1200001061),(1200000006,1200001062,'','','','192.0.2.22',1200001062,'11000dc0adcf055bc42c6424a74489646fa9a2ee925e53896b26bfe95fa5ac722098b4f3a74def0917d91367eb60cc5b6e37eaaaabbbbccccdddd',NULL);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `evaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evaluation` (
  `entryID` bigint(20) NOT NULL,
  `id` bigint(20) NOT NULL,
  `point` int(11) DEFAULT NULL,
  `host` varchar(512) DEFAULT NULL,
  `dateTime` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`entryID`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `evaluation` WRITE;
/*!40000 ALTER TABLE `evaluation` DISABLE KEYS */;
INSERT INTO `evaluation` VALUES (1200000001,1200001011,30,'192.0.2.21',1200001011),(1200000001,1200002001,20,'192.0.2.30',1200002001),(1200000002,1200001021,30,'192.0.2.21',1200001021),(1200000002,1200002002,20,'192.0.2.30',1200002002),(1200000003,1200001031,30,'192.0.2.21',1200001031),(1200000003,1200002003,20,'192.0.2.30',1200002003),(1200000004,1200001041,30,'192.0.2.21',1200001041),(1200000004,1200002004,20,'192.0.2.30',1200002004),(1200000005,1200001051,30,'192.0.2.21',1200001051),(1200000005,1200002005,20,'192.0.2.30',1200002005),(1200000006,1200001061,30,'192.0.2.21',1200001061),(1200000006,1200002006,20,'192.0.2.30',1200002006);
/*!40000 ALTER TABLE `evaluation` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta` (
  `name` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `meta` WRITE;
/*!40000 ALTER TABLE `meta` DISABLE KEYS */;
INSERT INTO `meta` VALUES ('author','2'),('dataVersion','1'),('tags','2'),('thread','2'),('threadEntry','3'),('threadEvaluation','4'),('threadStyle','3'),('threadTag','2');
/*!40000 ALTER TABLE `meta` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `searchIndex2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchIndex2` (
  `docid` bigint(20) NOT NULL,
  `title` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `summary` mediumtext COLLATE utf8_unicode_ci,
  `body` mediumtext COLLATE utf8_unicode_ci,
  `afterword` mediumtext COLLATE utf8_unicode_ci,
  `tag` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`docid`),
  FULLTEXT KEY `titleIndex` (`title`),
  FULLTEXT KEY `nameIndex` (`name`),
  FULLTEXT KEY `summaryIndex` (`summary`),
  FULLTEXT KEY `bodyIndex` (`body`),
  FULLTEXT KEY `afterwordIndex` (`afterword`),
  FULLTEXT KEY `tagIndex` (`tag`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `searchIndex2` WRITE;
/*!40000 ALTER TABLE `searchIndex2` DISABLE KEYS */;
INSERT INTO `searchIndex2` VALUES (1200000001,'lega egac gacy acy_ cy__ y___ pres rese eser serv erve rve_ ve__ e___ 旧作品_ 作品__ 品___','旧作者1 作者1_ 者1__ 1___',NULL,'p___ lega egac gacy acyb cybo ybod body odyp dypr ypre pres rese eser serv erve rve_ ve__ e___ 日本語_ 本語__ 語___ amp_ mp__ html tml_ ml__ l___ 二行目_ 行目__ 目___',NULL,'旧分類_ 分類__ 類___ role ole_ le__ e___ pres rese eser serv erve rve_ ve__'),(1200000002,'lega egac gacy acy_ cy__ y___ edit dit_ it__ t___ 旧作品_ 作品__ 品___','旧作者2 作者2_ 者2__ 2___',NULL,'p___ lega egac gacy acyb cybo ybod body odye dyed yedi edit dit_ it__ t___ 日本語_ 本語__ 語___ amp_ mp__ html tml_ ml__ l___ 二行目_ 行目__ 目___',NULL,'旧分類_ 分類__ 類___ role ole_ le__ e___ edit dit_ it__ t___'),(1200000003,'lega egac gacy acy_ cy__ y___ dele elet lete ete_ te__ e___ 旧作品_ 作品__ 品___','旧作者3 作者3_ 者3__ 3___',NULL,'p___ lega egac gacy acyb cybo ybod body odyd dyde ydel dele elet lete ete_ te__ e___ 日本語_ 本語__ 語___ amp_ mp__ html tml_ ml__ l___ 二行目_ 行目__ 目___',NULL,'旧分類_ 分類__ 類___ role ole_ le__ e___ dele elet lete ete_ te__'),(1200000004,'lega egac gacy acy_ cy__ y___ comm omme mmen ment ent_ nt__ t___ 旧作品_ 作品__ 品___','旧作者4 作者4_ 者4__ 4___',NULL,'p___ lega egac gacy acyb cybo ybod body odyc dyco ycom comm omme mmen ment ent_ nt__ t___ 日本語_ 本語__ 語___ amp_ mp__ html tml_ ml__ l___ 二行目_ 行目__ 目___',NULL,'旧分類_ 分類__ 類___ role ole_ le__ e___ comm omme mmen ment ent_ nt__ t___'),(1200000005,'lega egac gacy acy_ cy__ y___ eval valu alua luat uate ate_ te__ e___ 旧作品_ 作品__ 品___','旧作者5 作者5_ 者5__ 5___',NULL,'p___ lega egac gacy acyb cybo ybod body odye dyev yeva eval valu alua luat uate ate_ te__ e___ 日本語_ 本語__ 語___ amp_ mp__ html tml_ ml__ l___ 二行目_ 行目__ 目___',NULL,'旧分類_ 分類__ 類___ role ole_ le__ e___ eval valu alua luat uate ate_ te__'),(1200000006,'lega egac gacy acy_ cy__ y___ admi dmin min_ in__ n___ 旧作品_ 作品__ 品___','旧作者6 作者6_ 者6__ 6___',NULL,'p___ lega egac gacy acyb cybo ybod body odya dyad yadm admi dmin min_ in__ n___ 日本語_ 本語__ 語___ amp_ mp__ html tml_ ml__ l___ 二行目_ 行目__ 目___',NULL,'旧分類_ 分類__ 類___ role ole_ le__ e___ admi dmin min_ in__ n___');
/*!40000 ALTER TABLE `searchIndex2` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `lastUpdate` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` VALUES (1,1200000106);
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `tag` varchar(255) NOT NULL,
  `threadCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag`),
  KEY `tagsThreadCountIndex` (`threadCount`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES ('role-admin',1),('role-comment',1),('role-delete',1),('role-edit',1),('role-evaluate',1),('role-preserve',1),('旧分類',6);
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thread` (
  `id` bigint(20) NOT NULL,
  `subject` int(11) NOT NULL,
  `body` mediumtext,
  `afterword` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `thread` WRITE;
/*!40000 ALTER TABLE `thread` DISABLE KEYS */;
INSERT INTO `thread` VALUES (1200000001,1,'<p>legacybodypreserve 日本語 &amp; HTML</p>\r\n二行目',NULL),(1200000002,1,'<p>legacybodyedit 日本語 &amp; HTML</p>\r\n二行目',''),(1200000003,1,'<p>legacybodydelete 日本語 &amp; HTML</p>\r\n二行目',NULL),(1200000004,1,'<p>legacybodycomment 日本語 &amp; HTML</p>\r\n二行目',''),(1200000005,1,'<p>legacybodyevaluate 日本語 &amp; HTML</p>\r\n二行目',NULL),(1200000006,1,'<p>legacybodyadmin 日本語 &amp; HTML</p>\r\n二行目','');
/*!40000 ALTER TABLE `thread` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `threadEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `threadEntry` (
  `id` bigint(20) NOT NULL,
  `subject` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `summary` text,
  `link` varchar(512) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `host` varchar(512) DEFAULT NULL,
  `dateTime` bigint(20) DEFAULT NULL,
  `lastUpdate` bigint(20) DEFAULT NULL,
  `pageCount` int(11) DEFAULT NULL,
  `size` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `threadEntrySubjectIndex` (`subject`),
  KEY `threadEntryNameIndex` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `threadEntry` WRITE;
/*!40000 ALTER TABLE `threadEntry` DISABLE KEYS */;
INSERT INTO `threadEntry` VALUES (1200000001,1,'legacy-preserve 旧作品','旧作者1',NULL,'https://example.invalid/old/1',NULL,'192.0.2.1',1200000001,1200000101,1,0),(1200000002,1,'legacy-edit 旧作品','旧作者2','','https://example.invalid/old/2','legacy@example.invalid','192.0.2.2',1200000002,1200000102,1,0),(1200000003,1,'legacy-delete 旧作品','旧作者3',NULL,'https://example.invalid/old/3',NULL,'192.0.2.3',1200000003,1200000103,1,0),(1200000004,1,'legacy-comment 旧作品','旧作者4','','https://example.invalid/old/4','legacy@example.invalid','192.0.2.4',1200000004,1200000104,1,0),(1200000005,1,'legacy-evaluate 旧作品','旧作者5',NULL,'https://example.invalid/old/5',NULL,'192.0.2.5',1200000005,1200000105,1,0),(1200000006,1,'legacy-admin 旧作品','旧作者6','','https://example.invalid/old/6','legacy@example.invalid','192.0.2.6',1200000006,1200000106,1,0);
/*!40000 ALTER TABLE `threadEntry` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`fixture`@`%`*/ /*!50003 trigger authorInsertTrigger after insert on threadEntry for each row
				begin
					replace into author
					select name, count(id) as threadCount from threadEntry
					where name = new.name
					group by name;
				end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`fixture`@`%`*/ /*!50003 trigger authorUpdateTrigger after update on threadEntry for each row
				begin
					update author
					set threadCount = threadCount - 1
					where name = old.name;
					
					delete from author where name = old.name and threadCount = 0;
					
					replace into author
					select name, count(id) as threadCount from threadEntry
					where name = new.name
					group by name;
				end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`fixture`@`%`*/ /*!50003 trigger authorDeleteTrigger after delete on threadEntry for each row
				begin
					update author
					set threadCount = threadCount - 1
					where name = old.name;
					
					delete from author where name = old.name and threadCount = 0;
				end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `threadEvaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `threadEvaluation` (
  `id` bigint(20) NOT NULL,
  `points` int(11) DEFAULT NULL,
  `responseCount` int(11) DEFAULT NULL,
  `commentCount` int(11) DEFAULT NULL,
  `evaluationCount` int(11) DEFAULT NULL,
  `readCount` int(11) DEFAULT NULL,
  `responseLastUpdate` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `threadEvaluation` WRITE;
/*!40000 ALTER TABLE `threadEvaluation` DISABLE KEYS */;
INSERT INTO `threadEvaluation` VALUES (1200000001,50,3,2,2,7,1200002001),(1200000002,50,3,2,2,7,1200002002),(1200000003,50,3,2,2,7,1200002003),(1200000004,50,3,2,2,7,1200002004),(1200000005,50,3,2,2,7,1200002005),(1200000006,50,3,2,2,7,1200002006);
/*!40000 ALTER TABLE `threadEvaluation` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `threadPassword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `threadPassword` (
  `id` bigint(20) NOT NULL,
  `hash` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `threadPassword` WRITE;
/*!40000 ALTER TABLE `threadPassword` DISABLE KEYS */;
INSERT INTO `threadPassword` VALUES (1200000001,'11000bd81eea8e0cc385ac3731b6de39b62b22716917045fad58c6d91ba73a70d56b20419a0a0040ed1c343aacf08ebbe2ee60123456789abcdef'),(1200000002,'11000908d2685e6ce4a0863c57d1dea14acfc4558f4148be27b3a3b5c069b51773be51ce6524b70456a975c69644b1b174e8b0123456789abcdef'),(1200000003,'0ad7638c03c526fbbda443fd022ee6284cfb89bd'),(1200000004,'11000a96d949a73692770a8a4bd7ec3f165cb1fea6eef08e7b784a08594c7f57fe2e3212aa01a89586c8f62a604bafe7e69d70123456789abcdef'),(1200000005,'abY4FnAUJdZhE'),(1200000006,'110008a9f8ba0de89305c5d694e5676c8c050cff2d5a96639cb2bf97df42ce34ee3152cf4f498bc83a2d642ef50cb326683700123456789abcdef');
/*!40000 ALTER TABLE `threadPassword` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `threadStyle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `threadStyle` (
  `id` bigint(20) NOT NULL,
  `convertLineBreak` bit(1) DEFAULT NULL,
  `foreground` varchar(127) DEFAULT NULL,
  `background` varchar(127) DEFAULT NULL,
  `backgroundImage` varchar(512) DEFAULT NULL,
  `border` varchar(127) DEFAULT NULL,
  `writingMode` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `threadStyle` WRITE;
/*!40000 ALTER TABLE `threadStyle` DISABLE KEYS */;
INSERT INTO `threadStyle` VALUES (1200000001,NULL,'#123456',NULL,NULL,'#654321',1),(1200000002,NULL,'#123456',NULL,NULL,'#654321',1),(1200000003,NULL,'#123456',NULL,NULL,'#654321',1),(1200000004,NULL,'#123456',NULL,NULL,'#654321',1),(1200000005,NULL,'#123456',NULL,NULL,'#654321',1),(1200000006,NULL,'#123456',NULL,NULL,'#654321',1);
/*!40000 ALTER TABLE `threadStyle` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `threadTag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `threadTag` (
  `id` bigint(20) NOT NULL,
  `tag` varchar(255) NOT NULL,
  `position` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`tag`),
  KEY `threadTagTagIndex` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `threadTag` WRITE;
/*!40000 ALTER TABLE `threadTag` DISABLE KEYS */;
INSERT INTO `threadTag` VALUES (1200000001,'role-preserve',1),(1200000001,'旧分類',0),(1200000002,'role-edit',1),(1200000002,'旧分類',0),(1200000003,'role-delete',1),(1200000003,'旧分類',0),(1200000004,'role-comment',1),(1200000004,'旧分類',0),(1200000005,'role-evaluate',1),(1200000005,'旧分類',0),(1200000006,'role-admin',1),(1200000006,'旧分類',0);
/*!40000 ALTER TABLE `threadTag` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`fixture`@`%`*/ /*!50003 trigger tagsInsertTrigger after insert on threadTag for each row
				begin
					replace into tags
					select tag, count(id) as threadCount from threadTag
					where tag = new.tag
					group by tag;
				end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`fixture`@`%`*/ /*!50003 trigger tagsUpdateTrigger after update on threadTag for each row
				begin
					update tags
					set threadCount = threadCount - 1
					where tag = old.tag;
					
					delete from tags where tag = old.tag and threadCount = 0;
					
					replace into tags
					select tag, count(id) as threadCount from threadTag
					where tag = new.tag
					group by tag;
				end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`fixture`@`%`*/ /*!50003 trigger tagsDeleteTrigger after delete on threadTag for each row
				begin
					update tags
					set threadCount = threadCount - 1
					where tag = old.tag;
					
					delete from tags where tag = old.tag and threadCount = 0;
				end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

